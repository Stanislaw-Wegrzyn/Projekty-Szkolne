﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista_10___Nuty
{
    public enum KodNuty
    {
        C4,
        D5,
        E5,
        F5,
        G5,
        A5,
        B5,
        C5,
        Pauza
    }

    public enum DlugoscZnaku
    {
        calaNuta,
        polNuta,
        cwiartka,
        osemka
    }

    public enum TypZnaku
    {
        nuta,
        pauza
    }

    public enum TypEdycji
    {
        Lista,
        Kolajeka,
        Stos
    }
}
