<?php
    echo <<< OBRAZEK_I_PODPIS
    <img src='obraz1.png' alt='obraz 1' width='300px' height='200px'>
    <p>Obraz pierwszej sekcji</p>
    OBRAZEK_I_PODPIS;
?>