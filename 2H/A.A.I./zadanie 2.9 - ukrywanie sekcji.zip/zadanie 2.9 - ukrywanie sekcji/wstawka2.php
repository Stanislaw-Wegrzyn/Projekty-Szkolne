<?php
    echo <<< OBRAZEK_I_PODPIS
    <img src='obraz2.png' alt='obraz 2' width='300px' height='200px'>
    <p>Oto obraz drugiej sekcji</p>
    OBRAZEK_I_PODPIS;
?>