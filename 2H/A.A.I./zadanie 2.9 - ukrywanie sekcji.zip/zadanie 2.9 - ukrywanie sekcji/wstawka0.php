<?php
    echo "<h4>Wstawka lewego panelu</h4>"
?>